// Ingesta automática del catálogo (Jamendo -> Supabase). Se ejecuta a diario con GitHub Actions.
// Solo guarda METADATOS y la URL oficial de streaming del proveedor; no copia ni re-aloja audio.
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, JAMENDO_CLIENT_ID } = process.env;
const PAGES = Number(process.env.INGEST_PAGES ?? 4), PAGE_SIZE = 50;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !JAMENDO_CLIENT_ID) {
  console.error('Faltan SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY o JAMENDO_CLIENT_ID'); process.exit(1);
}
const rest = async (path, body, conflict) => {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}?on_conflict=${conflict}`, {
    method: 'POST',
    headers: { apikey: SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=representation' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`${path}: ${res.status} ${await res.text()}`);
  return res.json();
};
const commercial = (url = '') => url !== '' && !/-nc/i.test(url);

let total = 0;
for (let page = 0; page < PAGES; page++) {
  const qs = new URLSearchParams({ client_id: JAMENDO_CLIENT_ID, format: 'json', include: 'musicinfo', audioformat: 'mp32',
    limit: String(PAGE_SIZE), offset: String(page * PAGE_SIZE), order: 'releasedate_desc' });
  const res = await fetch(`https://api.jamendo.com/v3.0/tracks/?${qs}`);
  if (!res.ok) throw new Error(`Jamendo ${res.status}`);
  const items = (await res.json()).results ?? [];
  if (!items.length) break;

  const artistRows = [...new Map(items.map((t) => [t.artist_id, { provider_id: 'jamendo', external_id: String(t.artist_id), name: t.artist_name }])).values()];
  const artists = await rest('artists', artistRows, 'provider_id,external_id');
  const artistId = new Map(artists.map((a) => [a.external_id, a.id]));

  const trackRows = items.filter((t) => t.audio).map((t) => ({
    provider_id: 'jamendo', external_id: String(t.id), artist_id: artistId.get(String(t.artist_id)),
    title: t.name, duration_sec: t.duration, audio_url: t.audio, cover_url: t.album_image || t.image,
    genres: t.musicinfo?.tags?.genres ?? [], license: t.license_ccurl, commercial_use: commercial(t.license_ccurl),
    rights_status: 'playable_licensed', release_date: t.releasedate || null, territories: null,
  }));
  await rest('tracks', trackRows, 'provider_id,external_id');
  total += trackRows.length;
  await new Promise((r) => setTimeout(r, 500)); // ritmo moderado con la API
}
console.log(`Ingesta completada: ${total} pistas procesadas`);
