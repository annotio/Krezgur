# Resona · Plan técnico y viabilidad (0 €)

Condiciones comprobadas el 8-nov-2026 en fuentes públicas. **Revísalas antes de lanzar: cambian.**

## 1. Herramientas gratuitas evaluadas

| Servicio | Plan gratis | Límites clave | ¿Tarjeta? | Riesgo de coste | Decisión |
|---|---|---|---|---|---|
| Supabase | Auth + Postgres + Storage + Realtime | 2 proyectos, 500 MB BD, 1 GB archivos, 5 GB egress/mes, 50.000 MAU; **pausa tras 7 días sin actividad**; sin copias de seguridad | No | Con "spend cap" activo se bloquea en vez de cobrar | ✅ Usuarios, metadatos, playlists, campañas |
| Cloudflare Pages | Hosting estático | Ancho de banda estático ilimitado, 500 builds/mes, 20.000 archivos, 25 MiB/archivo | No | Funciones: 100.000 peticiones/día compartidas (se bloquea, no cobra) | ✅ Frontend |
| GitHub (público) | Repos + Actions | Minutos de Actions generosos en repos públicos | No | Ninguno | ✅ Código + ingesta diaria |
| **Cloudflare R2** | 10 GB gratis | — | **Sí (exige método de pago)** | Cobra si se supera el tramo | ❌ **Descartado** (regla 0) |
| Jamendo API | Catálogo Creative Commons | ~35.000 peticiones/mes; **solo uso no comercial** | No | Ninguno | ⚠️ Solo para demo/no comercial |
| LRCLIB | Letras sincronizadas, sin clave | Letras aportadas por la comunidad, **sin licencia de editoriales** | No | Legal | ⚠️ Desactivado por defecto |
| MusicBrainz | Metadatos abiertos | 1 petición/s | No | Ninguno | 🔜 Fase siguiente (metadatos) |

## 2. El problema que condiciona todo: derechos

1. **No hay catálogo comercial gratis.** Sellos mayores no se licencian con 0 €. Solo es legal reproducir lo que tiene licencia o autorización.
2. **Jamendo:** su API es gratuita *solo para uso no comercial* y define como comercial cualquier ingreso, **incluida la publicidad**. Con Jamendo gratis, los anuncios con pago real no son legales. Por eso `VITE_ADS_ENABLED=false` por defecto y cada pista guarda `commercial_use`.
3. **Camino viable para monetizar:** (a) música subida por artistas que aceptan unas condiciones de cesión, (b) pistas CC0/CC-BY/CC-BY-SA con atribución, (c) licencia comercial de Jamendo (de pago, cuando haya ingresos).
4. **Letras:** sin proveedor gratuito licenciado. Solo se mostrarán letras que suba el propio artista (LRC) o de pistas con licencia que las incluya.

Clasificación en BD (`rights_status`): `playable_licensed` (se reproduce) · `external_link` · `demo` · `pending_authorization`. El reproductor **se niega** a reproducir cualquier otra cosa.

## 3. Límites de capacidad (matemática real)

- 1 GB de Storage ≈ 250 canciones de 4 min a 128 kbps; 5 GB de egress ≈ 1.300 reproducciones completas/mes. Por eso el audio **no se aloja**: se transmite desde la URL oficial del proveedor.
- Los artistas que suban audio propio necesitarán otro almacenamiento (Internet Archive o similar, a estudiar) o pasar a plan de pago cuando haya ingresos.

## 4. Arquitectura

```
React + Vite (Cloudflare Pages) ──► Supabase (Auth · Postgres · RLS)
        │                                   ▲
        └─► Proveedores (src/providers)     │ scripts/ingest.mjs (GitHub Actions, diario)
```
Módulos: `providers` (fuentes), `catalog`, `player`, `auth`, `ads` (reglas + SQL). Cambiar de proveedor = nuevo archivo que implemente `MusicProvider`.

## 5. Estado

| Módulo | Estado |
|---|---|
| BD + RLS: usuarios, roles, catálogo con estado de derechos, playlists, favoritos, escuchas verificadas, campañas, eventos (0001 + 0002) | ✅ escrito |
| Reglas de anuncios (impresión / iniciada / válida, frecuencia, presupuesto), búsqueda por intención y parser de letras LRC | ✅ con pruebas automáticas (`npm test`) |
| `record_ad_event()` (consentimiento, tope de frecuencia, secuencia started→valid, descuento de presupuesto) | ✅ escrito, **sin ejecutar** |
| Proveedor Jamendo + ingesta diaria (GitHub Actions) | ✅ escrito; requiere tus claves |
| Reproductor: cola, aleatorio, repetir, volumen, temporizador, Media Session, última posición, escuchas verificadas, pausas publicitarias | ✅ escrito, **sin probar en navegador** |
| Pantalla de reproducción ampliada con letras sincronizadas (solo si la BD tiene letra autorizada) | ✅ |
| Playlists (crear, borrar, pública/privada, reordenar, añadir/quitar), favoritos, búsqueda en vivo con recientes | ✅ |
| Recomendaciones («Para ti») y búsqueda en lenguaje natural con reglas propias (sin IA de pago) | ✅ básicas |
| Panel de anunciante (campañas, estadísticas por país/dispositivo), panel de artista (reproducciones verificadas), panel admin (roles, aprobación de campañas, verificación de artistas, KPIs) | ✅ |
| RGPD: consentimiento publicitario, exportar mis datos, eliminar cuenta | ✅ |
| Ecualizador y calidad de audio configurable | ⏳ no implementado |
| Perfil público de artista (página), seguir artistas, rankings, álbumes/discografías en la UI | ⏳ tablas listas, UI pendiente |
| Subida de audio por artistas | ⛔ requiere almacenamiento (Supabase gratis = 1 GB) |
| Letras licenciadas para canciones comerciales | ⛔ requiere acuerdo/licencia |
| Cobros reales, facturación y suscripciones Premium | ⛔ requiere pasarela de pago; el importe es solo contable |
| Anti-fraude avanzado y detección de bots | ⛔ solo hay límites básicos; un cliente malicioso autenticado puede intentar falsear eventos: antes de cobrar dinero real hace falta verificación en servidor |
| Copias de seguridad | ⛔ no incluidas en Supabase gratis |

Todo lo marcado ✅ está **escrito pero no ha sido ejecutado en tu proyecto Supabase ni en un navegador**. Espera encontrar errores en la primera ejecución.
