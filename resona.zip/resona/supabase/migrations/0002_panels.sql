-- Resona · 0002: aprobación de campañas, paneles y RGPD. Ejecutar después de 0001.
alter table campaigns add column approved boolean not null default false;

-- El anunciante pausa/reactiva solo si el admin aprobó; nadie salvo admin toca approved ni spent_micros
create or replace function protect_campaign() returns trigger language plpgsql as
$$ begin
  if current_user <> 'postgres' and not is_admin() then
    new.spent_micros := old.spent_micros;
    new.approved := old.approved;
    if new.status is distinct from old.status then
      if not (old.approved and new.status in ('paused','active') and old.status in ('paused','active')) then
        new.status := old.status;
      end if;
    end if;
  end if; return new; end $$;

drop policy "campañas del anunciante" on campaigns;
create policy "campañas del anunciante" on campaigns for all
  using (exists (select 1 from advertisers a where a.id = advertiser_id and (a.owner_id = auth.uid() or is_admin())))
  with check (exists (select 1 from advertisers a where a.id = advertiser_id and (a.owner_id = auth.uid() or is_admin())));
drop policy "campañas activas visibles" on campaigns;
create policy "campañas activas visibles" on campaigns for select using (status = 'active' and approved);

-- record_ad_event exige campaña aprobada
create or replace function record_ad_event(p_campaign uuid, p_kind ad_event_kind, p_country text default null, p_device text default null)
returns void language plpgsql security definer set search_path = public as $$
declare c campaigns; uid uuid := auth.uid(); consent boolean;
begin
  if uid is null then raise exception 'auth required'; end if;
  select * into c from campaigns where id = p_campaign for update;
  if not found or c.status <> 'active' or not c.approved or now() not between c.starts_at and c.ends_at then return; end if;
  select ads_consent into consent from profiles where id = uid;
  if not coalesce(consent, false) then return; end if;
  if p_kind = 'started' and (select count(*) from ad_events where campaign_id = c.id and user_id = uid
       and kind = 'started' and created_at > now() - interval '1 day') >= c.freq_cap_per_day then return; end if;
  if p_kind = 'valid' then
    if not exists (select 1 from ad_events where campaign_id = c.id and user_id = uid and kind = 'started'
         and created_at > now() - interval '10 minutes'
         and created_at > coalesce((select max(created_at) from ad_events where campaign_id = c.id and user_id = uid and kind = 'valid'), '-infinity'))
    then return; end if;
    if c.spent_micros + c.price_micros > c.budget_micros then
      update campaigns set status = 'exhausted' where id = c.id; return;
    end if;
    update campaigns set spent_micros = spent_micros + price_micros,
      status = case when spent_micros + 2 * price_micros > budget_micros then 'exhausted' else status end
    where id = c.id;
  end if;
  insert into ad_events (campaign_id, user_id, kind, country, device) values (c.id, uid, p_kind, p_country, p_device);
end $$;

-- Artista: ver escuchas de sus propias pistas (artists.owner_id lo asigna el admin al verificar)
create policy "artista ve escuchas de sus pistas" on play_events for select using (
  exists (select 1 from tracks t join artists a on a.id = t.artist_id where t.id = track_id and a.owner_id = auth.uid()));
create policy "artista edita su perfil" on artists for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Admin: estadísticas globales
create function admin_stats() returns json language sql stable security definer set search_path = public as $$
  select case when is_admin() then json_build_object(
    'users', (select count(*) from profiles), 'tracks', (select count(*) from tracks),
    'valid_plays', (select count(*) from play_events where valid),
    'campaigns', (select count(*) from campaigns), 'pending', (select count(*) from campaigns where not approved)) end $$;

-- RGPD: borrado de cuenta (cascada a perfil, favoritos, playlists, escuchas)
create function delete_my_account() returns void language plpgsql security definer set search_path = public, auth as
$$ begin if auth.uid() is null then raise exception 'auth required'; end if; delete from auth.users where id = auth.uid(); end $$;
