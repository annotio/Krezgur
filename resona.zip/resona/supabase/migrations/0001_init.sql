-- Resona · esquema inicial. Ejecutar en Supabase > SQL Editor (una sola vez).
create type user_role as enum ('listener','artist','advertiser','admin');
create type rights_status as enum ('playable_licensed','external_link','demo','pending_authorization');
create type ad_format as enum ('audio','banner','home','sponsored_playlist','featured_artist','sponsored_profile','promoted_track');
create type ad_event_kind as enum ('impression','started','valid','click');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text, role user_role not null default 'listener',
  country text, plan text not null default 'free',
  ads_consent boolean not null default false, created_at timestamptz default now()
);
create function is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin insert into profiles (id, display_name) values (new.id, split_part(new.email,'@',1)); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
-- Un usuario no puede auto-asignarse un rol distinto
create function protect_role() returns trigger language plpgsql as
$$ begin if new.role <> old.role and not is_admin() then new.role := old.role; end if; return new; end $$;
create trigger profiles_protect_role before update on profiles for each row execute function protect_role();

create table providers (
  id text primary key, name text not null,
  commercial_ok boolean not null default false, enabled boolean not null default true
);
insert into providers values
  ('jamendo','Jamendo (Creative Commons)', false, true),
  ('artists','Subidas de artistas', true, true);

create table artists (
  id uuid primary key default gen_random_uuid(),
  provider_id text references providers, external_id text, name text not null,
  bio text, image_url text, verified boolean not null default false,
  owner_id uuid references profiles, unique (provider_id, external_id)
);
create table albums (
  id uuid primary key default gen_random_uuid(),
  provider_id text references providers, external_id text,
  artist_id uuid references artists, title text not null, cover_url text,
  release_date date, kind text default 'album', genres text[] default '{}',
  unique (provider_id, external_id)
);
create table tracks (
  id uuid primary key default gen_random_uuid(),
  provider_id text references providers, external_id text,
  artist_id uuid references artists, album_id uuid references albums,
  title text not null, duration_sec int, audio_url text, cover_url text,
  genres text[] default '{}', license text, commercial_use boolean not null default false,
  rights_status rights_status not null default 'pending_authorization',
  territories text[],            -- null = todo el mundo
  release_date date, created_at timestamptz default now(),
  unique (provider_id, external_id)
);
create index tracks_title_idx on tracks using gin (to_tsvector('simple', title));
create table lyrics (
  track_id uuid primary key references tracks on delete cascade,
  synced_lrc text, plain text, source text not null, license text
);

create table playlists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles on delete cascade default auth.uid(),
  name text not null, is_public boolean not null default false, created_at timestamptz default now()
);
create table playlist_tracks (
  playlist_id uuid references playlists on delete cascade,
  track_id uuid references tracks on delete cascade,
  position int not null, primary key (playlist_id, track_id)
);
create table favorites (
  user_id uuid references profiles on delete cascade default auth.uid(),
  track_id uuid references tracks on delete cascade, primary key (user_id, track_id)
);
create table follows (
  user_id uuid references profiles on delete cascade default auth.uid(),
  artist_id uuid references artists on delete cascade, primary key (user_id, artist_id)
);

-- Reproducción verificada: >= 30 s escuchados o pista completada
create table play_events (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles on delete cascade default auth.uid(),
  track_id uuid not null references tracks on delete cascade,
  listened_sec int not null check (listened_sec between 0 and 7200),
  completed boolean not null default false,
  valid boolean generated always as (listened_sec >= 30 or completed) stored,
  country text, device text, created_at timestamptz default now()
);

-- Publicidad (importes en micro-euros: 1 € = 1.000.000). Sin pagos reales: solo contabilidad.
create table advertisers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles default auth.uid(),
  name text not null, kind text not null check (kind in ('artist','company','brand','agency','label'))
);
create table campaigns (
  id uuid primary key default gen_random_uuid(),
  advertiser_id uuid not null references advertisers on delete cascade,
  title text not null, description text, format ad_format not null,
  audio_url text, image_url text, link_url text,
  countries text[], genres text[],
  budget_micros bigint not null check (budget_micros > 0),
  price_micros bigint not null check (price_micros > 0),   -- precio por reproducción válida
  spent_micros bigint not null default 0,
  freq_cap_per_day int not null default 3,
  starts_at timestamptz not null, ends_at timestamptz not null,
  status text not null default 'paused' check (status in ('paused','active','exhausted','rejected')),
  created_at timestamptz default now()
);
create table ad_events (
  id bigint generated always as identity primary key,
  campaign_id uuid not null references campaigns,
  user_id uuid references profiles default auth.uid(),
  kind ad_event_kind not null, country text, device text, created_at timestamptz default now()
);
create index ad_events_lookup on ad_events (campaign_id, user_id, kind, created_at);

-- Registro de eventos publicitarios en servidor: consentimiento, tope de frecuencia,
-- secuencia started -> valid, y descuento de presupuesto. El cliente NO inserta en ad_events.
create function record_ad_event(p_campaign uuid, p_kind ad_event_kind, p_country text default null, p_device text default null)
returns void language plpgsql security definer set search_path = public as $$
declare c campaigns; uid uuid := auth.uid(); consent boolean;
begin
  if uid is null then raise exception 'auth required'; end if;
  select * into c from campaigns where id = p_campaign for update;
  if not found or c.status <> 'active' or now() not between c.starts_at and c.ends_at then return; end if;
  select ads_consent into consent from profiles where id = uid;
  if not coalesce(consent, false) then return; end if;
  if p_kind = 'started' and (select count(*) from ad_events where campaign_id = c.id and user_id = uid
       and kind = 'started' and created_at > now() - interval '1 day') >= c.freq_cap_per_day then return; end if;
  if p_kind = 'valid' then
    -- exige un 'started' reciente que aún no se haya validado
    if not exists (select 1 from ad_events where campaign_id = c.id and user_id = uid and kind = 'started'
         and created_at > now() - interval '10 minutes'
         and created_at > coalesce((select max(created_at) from ad_events where campaign_id = c.id and user_id = uid and kind = 'valid'), '-infinity'))
    then return; end if;
    if c.spent_micros + c.price_micros > c.budget_micros then
      update campaigns set status = 'exhausted' where id = c.id; return;
    end if;
    update campaigns set spent_micros = spent_micros + price_micros,
      status = case when spent_micros + 2 * price_micros > budget_micros then 'exhausted' else status end
    where id = c.id;
  end if;
  insert into ad_events (campaign_id, user_id, kind, country, device) values (c.id, uid, p_kind, p_country, p_device);
end $$;

-- Row Level Security
alter table profiles enable row level security; alter table providers enable row level security;
alter table artists enable row level security; alter table albums enable row level security;
alter table tracks enable row level security; alter table lyrics enable row level security;
alter table playlists enable row level security; alter table playlist_tracks enable row level security;
alter table favorites enable row level security; alter table follows enable row level security;
alter table play_events enable row level security; alter table advertisers enable row level security;
alter table campaigns enable row level security; alter table ad_events enable row level security;

create policy "perfil propio" on profiles for select using (id = auth.uid() or is_admin());
create policy "editar perfil propio" on profiles for update using (id = auth.uid() or is_admin());
create policy "catalogo publico" on providers for select using (true);
create policy "catalogo publico" on artists for select using (true);
create policy "catalogo publico" on albums for select using (true);
create policy "catalogo publico" on tracks for select using (true);
create policy "letras publicas" on lyrics for select using (true);
create policy "admin artistas" on artists for all using (is_admin()) with check (is_admin());
create policy "admin albumes" on albums for all using (is_admin()) with check (is_admin());
create policy "admin pistas" on tracks for all using (is_admin()) with check (is_admin());
create policy "playlists propias o publicas" on playlists for select using (owner_id = auth.uid() or is_public);
create policy "playlists escritura" on playlists for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "pl_tracks lectura" on playlist_tracks for select using (
  exists (select 1 from playlists p where p.id = playlist_id and (p.owner_id = auth.uid() or p.is_public)));
create policy "pl_tracks escritura" on playlist_tracks for all
  using (exists (select 1 from playlists p where p.id = playlist_id and p.owner_id = auth.uid()))
  with check (exists (select 1 from playlists p where p.id = playlist_id and p.owner_id = auth.uid()));
create policy "favoritos propios" on favorites for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "seguidos propios" on follows for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "historial propio" on play_events for select using (user_id = auth.uid() or is_admin());
create policy "registrar escucha" on play_events for insert with check (user_id = auth.uid());
create policy "anunciante propio" on advertisers for all using (owner_id = auth.uid() or is_admin()) with check (owner_id = auth.uid());
create policy "campañas del anunciante" on campaigns for all
  using (exists (select 1 from advertisers a where a.id = advertiser_id and (a.owner_id = auth.uid() or is_admin())))
  with check (exists (select 1 from advertisers a where a.id = advertiser_id and a.owner_id = auth.uid()));
create policy "campañas activas visibles" on campaigns for select using (status = 'active');
create policy "eventos del anunciante" on ad_events for select using (
  exists (select 1 from campaigns c join advertisers a on a.id = c.advertiser_id
          where c.id = campaign_id and (a.owner_id = auth.uid() or is_admin())));
-- ad_events no tiene política de insert: solo se escribe vía record_ad_event().

-- Un anunciante no puede tocar el gasto ni aprobarse a sí mismo: solo admin o record_ad_event()
create function protect_campaign() returns trigger language plpgsql as
$$ begin
  if current_user <> 'postgres' and not is_admin() then
    new.spent_micros := old.spent_micros;
    if new.status in ('active','exhausted','rejected') and new.status is distinct from old.status then new.status := old.status; end if;
  end if; return new; end $$;
create trigger campaigns_protect before update on campaigns for each row execute function protect_campaign();
