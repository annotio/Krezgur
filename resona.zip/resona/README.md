# Resona

Plataforma de streaming musical (proyecto 0 €). Léase primero `docs/PLAN.md` (viabilidad, límites y derechos).

## Puesta en marcha (todo gratis, sin tarjeta)

1. **Node 22** y `npm install` en esta carpeta.
2. **Supabase:** crea cuenta (sin tarjeta) → nuevo proyecto → SQL Editor → ejecuta **en orden** `supabase/migrations/0001_init.sql` y `0002_panels.sql`.
   Copia *Project URL* y *anon key* (Settings > API).
3. **Jamendo:** crea una app en https://developer.jamendo.com y copia el `client_id`.
4. Copia `.env.example` a `.env` y rellena `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_JAMENDO_CLIENT_ID`.
5. `npm run dev` → http://localhost:5173
6. Pruebas automáticas: `npm test` · Compilar: `npm run build`

> Sin Supabase, la app funciona en "modo directo" (solo escuchar, sin cuentas). Sin Jamendo ni catálogo, verás un aviso de catálogo vacío: no hay canciones de relleno.

## Catálogo automático
Sube el proyecto a un repo público de GitHub y añade en *Settings > Secrets and variables > Actions*: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` (¡secreta, nunca en el navegador!) y `JAMENDO_CLIENT_ID`. El workflow `.github/workflows/ingest.yml` importa nuevos lanzamientos cada día (también manual con *Run workflow*).

## Publicar gratis
Cloudflare Pages → Connect to Git → repo → build `npm run build`, salida `dist`, variables `VITE_*`. Cada `git push` actualiza la web (dirección `*.pages.dev`). Alternativa: GitHub Pages.

## Administrador
Regístrate en la app y, en Supabase > SQL Editor: `update profiles set role = 'admin' where id = '<tu uuid>';`
(El trigger impide que nadie se asigne roles desde la app.)

## Subir a GitHub
```bash
cd resona
git init && git add . && git commit -m "Resona: primera versión"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/resona.git   # crea antes un repo vacío (público) en github.com
git push -u origin main
```
Nunca subas `.env` (ya está en `.gitignore`). El workflow `ci.yml` ejecuta pruebas y compilación en cada push.

## Cómo funcionan los roles
- **Oyente:** todo usuario nuevo. **Anunciante:** cualquier usuario registrado puede crear su perfil de anunciante en «Publicidad».
- **Artista:** el admin vincula una cuenta a un artista del catálogo (Admin > Artistas).
- **Admin:** se asigna a mano en SQL (ver arriba). Las campañas solo se emiten tras su aprobación.

## Anuncios
Desactivados por defecto. Para activarlos: `VITE_ADS_ENABLED=true`, y solo si tu catálogo permite uso comercial (ver `docs/PLAN.md`, sección 2). El usuario debe haber dado su consentimiento en «Cuenta». No se procesan pagos reales.
