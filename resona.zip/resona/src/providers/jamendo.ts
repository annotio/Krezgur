import type { Track } from '../core/types';
import type { MusicProvider } from './types';

const BASE = 'https://api.jamendo.com/v3.0';

interface JamendoTrack {
  id: string; name: string; duration: number; artist_name: string; album_name?: string;
  album_image?: string; image?: string; audio?: string; license_ccurl?: string;
  musicinfo?: { tags?: { genres?: string[] } };
}

/** CC-BY-NC* no permite uso comercial. CC0 / CC-BY / CC-BY-SA sí (con sus condiciones de atribución). */
export const isCommercialLicense = (url = '') => url !== '' && !/-nc/i.test(url);

export function mapJamendo(t: JamendoTrack): Track {
  const license = t.license_ccurl ?? '';
  return {
    id: `jamendo:${t.id}`, providerId: 'jamendo', title: t.name, artistName: t.artist_name,
    albumTitle: t.album_name, coverUrl: t.album_image || t.image, audioUrl: t.audio,
    durationSec: t.duration, genres: t.musicinfo?.tags?.genres ?? [], license,
    commercialUse: isCommercialLicense(license),
    // Streaming directo desde la URL oficial de Jamendo (no se copia ni se re-aloja el audio).
    rights: t.audio ? 'playable_licensed' : 'pending_authorization',
  };
}

export function createJamendo(clientId: string): MusicProvider {
  async function call(params: Record<string, string>): Promise<Track[]> {
    const qs = new URLSearchParams({ client_id: clientId, format: 'json', include: 'musicinfo', audioformat: 'mp32', ...params });
    const res = await fetch(`${BASE}/tracks/?${qs}`);
    if (!res.ok) throw new Error(`Jamendo ${res.status}`);
    const json = await res.json();
    return (json.results as JamendoTrack[]).map(mapJamendo);
  }
  return {
    id: 'jamendo', name: 'Jamendo (Creative Commons)', commercialOk: false,
    search: (q, limit = 20) => call({ search: q, limit: String(limit), order: 'popularity_total' }),
    popular: (limit = 20) => call({ limit: String(limit), order: 'popularity_week' }),
    byTags: (tags, limit = 30) => call({ tags: tags.join('+'), limit: String(limit), order: 'popularity_week' }),
    latest: (limit = 20) => call({ limit: String(limit), order: 'releasedate_desc' }),
  };
}
