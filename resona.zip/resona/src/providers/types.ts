import type { Track } from '../core/types';

/** Contrato que debe cumplir cualquier fuente de catálogo. Añadir un proveedor = un archivo + registrarlo. */
export interface MusicProvider {
  id: string;
  name: string;
  /** false = la API/licencia general NO permite uso comercial (p. ej. Jamendo gratis). */
  commercialOk: boolean;
  search(query: string, limit?: number): Promise<Track[]>;
  popular(limit?: number): Promise<Track[]>;
  latest(limit?: number): Promise<Track[]>;
  byTags?(tags: string[], limit?: number): Promise<Track[]>;
}
