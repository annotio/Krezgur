import type { MusicProvider } from './types';
import { createJamendo } from './jamendo';

/** Registro central. Para añadir un proveedor nuevo (p. ej. subidas de artistas), regístralo aquí. */
export function buildProviders(): MusicProvider[] {
  const list: MusicProvider[] = [];
  const jamendoId = import.meta.env.VITE_JAMENDO_CLIENT_ID as string | undefined;
  if (jamendoId) list.push(createJamendo(jamendoId));
  return list;
}
export const providers = buildProviders();
