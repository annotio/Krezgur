import { useEffect, useState } from 'react';
import type { Track } from './core/types';
import { loadHome, search, listFavorites, setFavorite, recommend, type Home } from './modules/catalog/catalogService';
import { player, usePlayer, currentTrack } from './modules/player/playerStore';
import PlayerBar from './modules/player/PlayerBar';
import NowPlaying from './modules/player/NowPlaying';
import Playlists from './modules/library/Playlists';
import { myPlaylists, addToPlaylist, type Playlist } from './modules/library/libraryService';
import AccountPanel from './modules/panels/AccountPanel';
import AdvertiserPanel from './modules/panels/AdvertiserPanel';
import ArtistPanel from './modules/panels/ArtistPanel';
import AdminPanel from './modules/panels/AdminPanel';
import HomeBanner from './modules/ads/HomeBanner';
import { useProfile } from './modules/auth/useProfile';
import { isUuid } from './lib/supabase';

type View = 'home' | 'search' | 'library' | 'playlists' | 'ads' | 'artist' | 'admin' | 'account';

function Badge({ t }: { t: Track }) {
  if (t.rights !== 'playable_licensed') return <em className="badge warn">Sin audio autorizado</em>;
  return <em className={'badge ' + (t.commercialUse ? 'ok' : '')}>{t.commercialUse ? 'Licencia comercial' : 'Solo uso no comercial'}</em>;
}

interface ListProps { list: Track[]; favs?: Set<string>; toggle?: (t: Track) => void; onAdd?: (t: Track) => void }
function List({ list, favs, toggle, onAdd }: ListProps) {
  const s = usePlayer(); const cur = currentTrack(s)?.id;
  if (!list.length) return null;
  return (
    <ul className="list">{list.map((t, i) => (
      <li key={t.id} className={cur === t.id ? 'row active' : 'row'}>
        <button className="cover" onClick={() => player.playQueue(list, i)} aria-label={`Reproducir ${t.title}`}>
          {t.coverUrl ? <img src={t.coverUrl} alt="" loading="lazy" /> : <div className="ph" />}<span>▶</span></button>
        <div className="meta"><strong>{t.title}</strong><span>{t.artistName}</span></div>
        <Badge t={t} />
        {toggle && isUuid(t.id) ? <button className={favs?.has(t.id) ? 'heart on' : 'heart'} onClick={() => toggle(t)} aria-label="Favorito">♥</button> : <span />}
        <span style={{ display: 'flex' }}>
          <button className="mini" onClick={() => player.enqueue(t)} aria-label="Añadir a la cola" title="Añadir a la cola">＋</button>
          {onAdd && isUuid(t.id) && <button className="mini" onClick={() => onAdd(t)} aria-label="Añadir a playlist" title="Añadir a playlist">♫</button>}
        </span>
      </li>))}
    </ul>
  );
}

export default function App() {
  const [view, setView] = useState<View>('home');
  const [home, setHome] = useState<Home | null>(null); const [forYou, setForYou] = useState<Track[]>([]);
  const [q, setQ] = useState(''); const [results, setResults] = useState<Track[]>([]); const [recent, setRecent] = useState<string[]>(() => JSON.parse(localStorage.getItem('rs.recent') ?? '[]'));
  const [favList, setFavList] = useState<Track[]>([]); const favs = new Set<string>(favList.map((t) => t.id));
  const [light, setLight] = useState(false); const [full, setFull] = useState(false); const [err, setErr] = useState('');
  const [addFor, setAddFor] = useState<Track | null>(null); const [pls, setPls] = useState<Playlist[]>([]);
  const { session, profile, ownsArtist } = useProfile();

  useEffect(() => { loadHome().then(setHome).catch((e) => setErr(String(e))); }, []);
  useEffect(() => { document.documentElement.dataset.theme = light ? 'light' : 'dark'; }, [light]);
  useEffect(() => { if (session) { listFavorites().then(setFavList); recommend().then(setForYou); } else { setFavList([]); setForYou([]); } }, [session]);
  useEffect(() => {
    const id = setTimeout(() => {
      search(q).then((r) => { setResults(r); if (q.trim().length > 2 && r.length) { const n = [q.trim(), ...recent.filter((x) => x !== q.trim())].slice(0, 6); setRecent(n); localStorage.setItem('rs.recent', JSON.stringify(n)); } }).catch((e) => setErr(String(e)));
    }, 400); // búsqueda en vivo con debounce
    return () => clearTimeout(id);
  }, [q]); // eslint-disable-line

  const toggleFav = async (t: Track) => { const on = !favs.has(t.id); await setFavorite(t.id, on); setFavList(on ? [...favList, t] : favList.filter((x) => x.id !== t.id)); };
  const openAdd = async (t: Track) => { if (!session) { alert('Inicia sesión para usar playlists.'); return; } setPls(await myPlaylists()); setAddFor(t); };

  const nav: [View, string][] = [['home', 'Inicio'], ['search', 'Buscar'], ['library', 'Favoritos'], ['playlists', 'Playlists']];
  if (session) nav.push(['ads', 'Publicidad']);
  if (ownsArtist) nav.push(['artist', 'Artista']);
  if (profile?.role === 'admin') nav.push(['admin', 'Admin']);
  nav.push(['account', 'Cuenta']);
  const lp = { favs, toggle: toggleFav, onAdd: openAdd };

  return (
    <div className="app">
      <nav className="side-nav">
        <h1>Resona</h1>
        {nav.map(([v, label]) => <button key={v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>{label}</button>)}
        <button className="theme" onClick={() => setLight(!light)}>{light ? '🌙 Oscuro' : '☀️ Claro'}</button>
      </nav>
      <main>
        {err && <p className="err">{err}</p>}
        {view === 'home' && <>
          <h2>{session ? `Hola, ${session.user.email?.split('@')[0]}` : 'Hola'} 👋</h2>
          <HomeBanner />
          {home?.source === 'none' && <p className="note">Aún no hay catálogo. Configura Jamendo o ejecuta la ingesta (ver README). No se muestran canciones de relleno.</p>}
          {home && home.source !== 'none' && <p className="note">Fuente: {home.source === 'database' ? 'catálogo propio (base de datos)' : 'consulta directa al proveedor'}</p>}
          {!!forYou.length && <><h3>Para ti</h3><List list={forYou} {...lp} /></>}
          {!!home?.latest.length && <><h3>Nuevos lanzamientos</h3><List list={home.latest} {...lp} /></>}
          {!!home?.popular.length && <><h3>Populares</h3><List list={home.popular} {...lp} /></>}
          <h3>Según tu ánimo</h3>
          <p>{['Entrenar', 'Estudiar', 'Relajarme', 'Fiesta'].map((m) => <button key={m} className="chip" onClick={() => { setQ(`música para ${m.toLowerCase()}`); setView('search'); }}>{m}</button>)}</p>
        </>}
        {view === 'search' && <>
          <input className="search" autoFocus placeholder="Prueba: «música tranquila para estudiar»" value={q} onChange={(e) => setQ(e.target.value)} />
          {!q && recent.length > 0 && <p>{recent.map((r) => <button key={r} className="chip" onClick={() => setQ(r)}>{r}</button>)}</p>}
          {q && !results.length && <p className="note">Sin resultados.</p>}
          <List list={results} {...lp} />
        </>}
        {view === 'library' && (session ? (favList.length ? <><h2>Tus favoritos</h2><List list={favList} {...lp} /></> : <p className="note">Aún no tienes favoritos.</p>) : <p className="note">Inicia sesión en «Cuenta».</p>)}
        {view === 'playlists' && (session ? <Playlists /> : <p className="note">Inicia sesión en «Cuenta».</p>)}
        {view === 'ads' && session && <AdvertiserPanel />}
        {view === 'artist' && ownsArtist && <ArtistPanel />}
        {view === 'admin' && profile?.role === 'admin' && <AdminPanel />}
        {view === 'account' && <AccountPanel />}
      </main>
      <PlayerBar onExpand={() => setFull(true)} />
      {full && <NowPlaying onClose={() => setFull(false)} />}
      {addFor && (
        <div className="modal" onClick={() => setAddFor(null)}><div className="card" onClick={(e) => e.stopPropagation()}>
          <h3>Añadir «{addFor.title}»</h3>
          {pls.map((p) => <button key={p.id} className="btn ghost" style={{ display: 'block', margin: '6px 0' }} onClick={async () => { await addToPlaylist(p.id, addFor.id); setAddFor(null); }}>{p.name}</button>)}
          {!pls.length && <p className="note">Crea una playlist primero en «Playlists».</p>}
        </div></div>
      )}
    </div>
  );
}
