/** Estado de derechos: el reproductor solo reproduce 'playable_licensed'. */
export type RightsStatus = 'playable_licensed' | 'external_link' | 'demo' | 'pending_authorization';

export interface Track {
  id: string;               // id interno (uuid en BD) o `${provider}:${externalId}` en modo directo
  providerId: string;
  title: string;
  artistName: string;
  albumTitle?: string;
  coverUrl?: string;
  audioUrl?: string;
  durationSec: number;
  genres: string[];
  license?: string;         // URL de la licencia (p. ej. Creative Commons)
  commercialUse: boolean;   // ¿la licencia permite uso comercial (incluida publicidad)?
  rights: RightsStatus;
}
