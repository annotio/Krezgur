import { useEffect, useState } from 'react';
import { pickAd, recordAdEvent, type Campaign } from './adService';

/** Anuncio de portada. Impresión = visible 1 s; clic = reproducción válida del formato. */
export default function HomeBanner() {
  const [ad, setAd] = useState<Campaign | null>(null);
  useEffect(() => { pickAd('home').then(setAd); }, []);
  useEffect(() => { if (!ad) return; const id = setTimeout(() => void recordAdEvent(ad.id, 'impression'), 1000); return () => clearTimeout(id); }, [ad]);
  if (!ad) return null;
  return (
    <a className="banner" href={ad.link_url ?? '#'} target="_blank" rel="noopener sponsored" onClick={async () => { await recordAdEvent(ad.id, 'started'); await recordAdEvent(ad.id, 'click'); await recordAdEvent(ad.id, 'valid'); }}>
      {ad.image_url && <img src={ad.image_url} alt="" />}<div><em className="badge warn">Patrocinado</em><strong>{ad.title}</strong><span>{ad.description}</span></div>
    </a>
  );
}
