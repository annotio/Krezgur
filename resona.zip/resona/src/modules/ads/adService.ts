import { supabase } from '../../lib/supabase';

export const ADS_ENABLED = import.meta.env.VITE_ADS_ENABLED === 'true';

export interface Campaign {
  id: string; title: string; format: string; audio_url?: string; image_url?: string; link_url?: string;
  description?: string; countries?: string[]; genres?: string[];
}
const device = () => (/Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : 'desktop');

export async function hasConsent(): Promise<boolean> {
  if (!supabase) return false;
  const { data: u } = await supabase.auth.getUser(); if (!u.user) return false;
  const { data } = await supabase.from('profiles').select('ads_consent').eq('id', u.user.id).single();
  return !!data?.ads_consent;
}
export async function setConsent(v: boolean) {
  const { data: u } = await supabase!.auth.getUser();
  await supabase!.from('profiles').update({ ads_consent: v }).eq('id', u.user!.id);
}

/** Elige una campaña activa y aprobada del formato dado (RLS ya filtra estado/aprobación). */
export async function pickAd(format: string, country?: string): Promise<Campaign | null> {
  if (!ADS_ENABLED || !supabase || !(await hasConsent())) return null;
  const now = new Date().toISOString();
  const { data } = await supabase.from('campaigns').select('*').eq('format', format)
    .lte('starts_at', now).gte('ends_at', now).limit(20);
  const ok = (data ?? []).filter((c: Campaign) => !c.countries?.length || !country || c.countries.includes(country));
  return ok.length ? ok[Math.floor(Math.random() * ok.length)] : null;
}
export async function recordAdEvent(campaignId: string, kind: 'impression' | 'started' | 'valid' | 'click', country?: string) {
  if (!supabase) return;
  await supabase.rpc('record_ad_event', { p_campaign: campaignId, p_kind: kind, p_country: country ?? null, p_device: device() });
}
