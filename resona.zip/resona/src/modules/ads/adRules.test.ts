import assert from 'node:assert/strict';
import { classifyAd, canServe, chargeValidPlay } from './adRules.ts';

const audio = { format: 'audio' as const, adDurationSec: 20, skipped: false, visibleMs: 0, clicked: false };
assert.equal(classifyAd({ ...audio, listenedSec: 0 }), 'none');
assert.equal(classifyAd({ ...audio, listenedSec: 5 }), 'started');
assert.equal(classifyAd({ ...audio, listenedSec: 16 }), 'valid');
assert.equal(classifyAd({ ...audio, listenedSec: 16, skipped: true }), 'started');
assert.equal(classifyAd({ ...audio, adDurationSec: 10, listenedSec: 8 }), 'valid'); // 80 % de 10 s
const banner = { format: 'banner' as const, adDurationSec: 0, listenedSec: 0, skipped: false, visibleMs: 1200, clicked: false };
assert.equal(classifyAd(banner), 'impression');       // una impresión NO es reproducción válida
assert.equal(classifyAd({ ...banner, visibleMs: 300 }), 'none');
assert.equal(classifyAd({ ...banner, clicked: true }), 'valid');

const now = Date.now();
assert.equal(canServe([now - 1000, now - 2000], now, 3), true);
assert.equal(canServe([now - 1000, now - 2000, now - 3000], now, 3), false);
assert.equal(canServe([now - 90_000_000, now - 91_000_000, now - 92_000_000], now, 3), true);

// 0,01 € = 10_000 micros; presupuesto 100 € = 100_000_000 → 10.000 reproducciones
let s = 0, n = 0;
for (;;) { const r = chargeValidPlay(s, 100_000_000, 10_000); if (!r.charged) break; s = r.spent; n++; }
assert.equal(n, 10_000); assert.equal(s, 100_000_000);
console.log('adRules: todas las pruebas OK');
