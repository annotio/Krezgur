/**
 * Reglas de contabilidad publicitaria (puras y testeables).
 * Distinguimos: impresión (se mostró) ≠ reproducción iniciada ≠ reproducción válida (se cobra).
 * La fuente de verdad del cobro es record_ad_event() en SQL; esto es la misma lógica para el cliente.
 */
export type AdFormat = 'audio' | 'banner' | 'home' | 'sponsored_playlist' | 'featured_artist' | 'sponsored_profile' | 'promoted_track';
export type AdStage = 'none' | 'impression' | 'started' | 'valid';

export interface AdObservation {
  format: AdFormat;
  adDurationSec: number;   // duración del anuncio (audio)
  listenedSec: number;     // segundos realmente reproducidos (audio)
  skipped: boolean;
  visibleMs: number;       // tiempo visible >=50% del área (visuales)
  clicked: boolean;
}

/** Audio: válida si escucha >= min(15 s, 80 % del anuncio) y no se saltó antes. Visual: válida = clic. */
export function classifyAd(o: AdObservation): AdStage {
  if (o.format === 'audio') {
    if (o.listenedSec <= 0) return 'none';
    const threshold = Math.min(15, o.adDurationSec * 0.8);
    return !o.skipped && o.listenedSec >= threshold ? 'valid' : 'started';
  }
  if (o.clicked) return 'valid';
  return o.visibleMs >= 1000 ? 'impression' : 'none';
}

/** Tope de frecuencia: máximo `cap` emisiones por usuario y campaña en 24 h. */
export function canServe(shownAtMs: number[], nowMs: number, cap: number): boolean {
  return shownAtMs.filter((t) => nowMs - t < 86_400_000).length < cap;
}

/** Descuento de presupuesto en micro-euros (1 € = 1_000_000). */
export function chargeValidPlay(spent: number, budget: number, price: number) {
  if (spent + price > budget) return { spent, charged: 0, exhausted: true };
  return { spent: spent + price, charged: price, exhausted: spent + 2 * price > budget };
}
