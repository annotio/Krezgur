import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useSession } from './useSession';

export interface Profile { id: string; display_name: string | null; role: 'listener' | 'artist' | 'advertiser' | 'admin'; ads_consent: boolean }
export function useProfile() {
  const session = useSession(); const [profile, setProfile] = useState<Profile | null>(null); const [ownsArtist, setOwns] = useState(false);
  useEffect(() => {
    if (!supabase || !session) { setProfile(null); setOwns(false); return; }
    supabase.from('profiles').select('id,display_name,role,ads_consent').eq('id', session.user.id).single().then(({ data }) => setProfile(data as Profile));
    supabase.from('artists').select('id', { count: 'exact', head: true }).eq('owner_id', session.user.id).then(({ count }) => setOwns((count ?? 0) > 0));
  }, [session]);
  return { session, profile, ownsArtist };
}
