import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useSession } from './useSession';

export default function AuthPanel() {
  const session = useSession();
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [msg, setMsg] = useState('');
  if (!supabase) return <p className="note">Cuentas desactivadas: falta configurar Supabase (ver README).</p>;
  if (session) return (
    <div><p>Sesión iniciada como <strong>{session.user.email}</strong></p>
      <button className="btn" onClick={() => supabase!.auth.signOut()}>Cerrar sesión</button></div>
  );
  const go = async (up: boolean) => {
    const { error } = up ? await supabase!.auth.signUp({ email, password }) : await supabase!.auth.signInWithPassword({ email, password });
    setMsg(error ? error.message : up ? 'Cuenta creada. Revisa tu correo si pide confirmación.' : '');
  };
  return (
    <div className="auth">
      <input type="email" placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Contraseña (mín. 6)" value={password} onChange={(e) => setPassword(e.target.value)} />
      <div><button className="btn" onClick={() => go(false)}>Entrar</button> <button className="btn ghost" onClick={() => go(true)}>Crear cuenta</button></div>
      {msg && <p className="note">{msg}</p>}
    </div>
  );
}
