import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useProfile } from '../auth/useProfile';
import { setConsent } from '../ads/adService';
import { exportMyData } from '../catalog/catalogService';
import AuthPanel from '../auth/AuthPanel';

export default function AccountPanel() {
  const { session, profile } = useProfile(); const [consent, setC] = useState<boolean | null>(null); const [msg, setMsg] = useState('');
  const checked = consent ?? profile?.ads_consent ?? false;
  return (
    <>
      <h2>Cuenta</h2><AuthPanel />
      {session && supabase && (
        <section className="card">
          <h3>Privacidad (RGPD)</h3>
          <label><input type="checkbox" checked={checked} onChange={async (e) => { setC(e.target.checked); await setConsent(e.target.checked); }} />
            {' '}Acepto recibir anuncios personalizados por país y género musical. Puedes retirarlo cuando quieras.</label>
          <p className="note">Solo guardamos: correo, tus escuchas, favoritos y playlists. Nada más.</p>
          <button className="btn ghost" onClick={async () => {
            const data = await exportMyData(); const a = document.createElement('a');
            a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })); a.download = 'mis-datos-resona.json'; a.click();
          }}>Descargar mis datos</button>{' '}
          <button className="btn danger" onClick={async () => {
            if (!confirm('Se eliminará tu cuenta y todos tus datos de forma permanente. ¿Continuar?')) return;
            const { error } = await supabase!.rpc('delete_my_account'); if (error) setMsg(error.message); else { await supabase!.auth.signOut(); location.reload(); }
          }}>Eliminar mi cuenta</button>
          {msg && <p className="err">{msg}</p>}
        </section>
      )}
    </>
  );
}
