import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

/* eslint-disable @typescript-eslint/no-explicit-any */
export default function ArtistPanel() {
  const [rows, setRows] = useState<any[]>([]); const [days, setDays] = useState<Record<string, number>>({}); const [artist, setArtist] = useState<any>(null);
  useEffect(() => { (async () => {
    const { data: u } = await supabase!.auth.getUser();
    const { data: a } = await supabase!.from('artists').select('*').eq('owner_id', u.user!.id).limit(1).maybeSingle(); setArtist(a); if (!a) return;
    const { data: t } = await supabase!.from('tracks').select('id,title').eq('artist_id', a.id);
    const ids = (t ?? []).map((x: any) => x.id); if (!ids.length) return;
    const since = new Date(Date.now() - 14 * 86400000).toISOString();
    const { data: ev } = await supabase!.from('play_events').select('track_id,valid,created_at').in('track_id', ids).gte('created_at', since).eq('valid', true).limit(10000);
    const per: Record<string, number> = {}, perDay: Record<string, number> = {};
    for (const e of ev ?? []) { per[e.track_id] = (per[e.track_id] ?? 0) + 1; const d = e.created_at.slice(0, 10); perDay[d] = (perDay[d] ?? 0) + 1; }
    setRows((t ?? []).map((x: any) => ({ ...x, plays: per[x.id] ?? 0 })).sort((a: any, b: any) => b.plays - a.plays)); setDays(perDay);
  })(); }, []);
  if (!artist) return <p className="note">Tu cuenta aún no está vinculada a un artista. Un administrador debe verificarte y vincularla.</p>;
  const max = Math.max(1, ...(Object.values(days) as number[]));
  return (
    <>
      <h2>{artist.name} {artist.verified && <em className="badge ok">Verificado</em>}</h2>
      <p className="note">Solo reproducciones <strong>verificadas</strong> (≥30 s o completas), últimos 14 días. No hay estimaciones.</p>
      <div className="spark">{(Object.entries(days) as [string, number][]).sort().map(([d, n]) => <div key={d} title={`${d}: ${n}`} style={{ height: `${(n / max) * 100}%` }} />)}</div>
      <ul className="list">{rows.map((r) => <li key={r.id} className="row" style={{ gridTemplateColumns: '1fr auto' }}><div className="meta"><strong>{r.title}</strong></div><span>{r.plays} reproducciones</span></li>)}</ul>
      {!rows.length && <p className="note">Sin datos todavía.</p>}
    </>
  );
}
