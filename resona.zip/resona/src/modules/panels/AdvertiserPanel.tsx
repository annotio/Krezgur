import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

/* eslint-disable @typescript-eslint/no-explicit-any */
const eur = (m: number) => (m / 1_000_000).toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 4 });
const FORMATS = ['audio', 'banner', 'home', 'sponsored_playlist', 'promoted_track', 'featured_artist', 'sponsored_profile'];
const KINDS: Record<string, string> = { artist: 'Artista', company: 'Empresa', brand: 'Marca', agency: 'Agencia', label: 'Discográfica' };

export default function AdvertiserPanel() {
  const [adv, setAdv] = useState<any>(null); const [camps, setCamps] = useState<any[]>([]); const [ev, setEv] = useState<any[]>([]);
  const [msg, setMsg] = useState(''); const [f, setF] = useState<any>({ format: 'audio', freq: 3, price: '0.01', budget: '10' });
  const load = async () => {
    const { data: a } = await supabase!.from('advertisers').select('*').limit(1).maybeSingle(); setAdv(a);
    if (!a) return;
    const { data: c } = await supabase!.from('campaigns').select('*').eq('advertiser_id', a.id).order('created_at', { ascending: false }); setCamps(c ?? []);
    if (c?.length) { const { data: e } = await supabase!.from('ad_events').select('campaign_id,kind,country,device,created_at').in('campaign_id', c.map((x: any) => x.id)).limit(5000); setEv(e ?? []); }
  };
  useEffect(() => { void load(); }, []);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const stats = (id: string) => {
    const mine = ev.filter((e) => e.campaign_id === id); const n = (k: string) => mine.filter((e) => e.kind === k).length;
    const by = (key: string) => Object.entries(mine.filter((e) => e.kind === 'valid').reduce((m: any, e) => { const v = e[key] ?? '—'; m[v] = (m[v] ?? 0) + 1; return m; }, {})).map(([k, v]) => `${k}: ${v}`).join(' · ') || '—';
    return { imp: n('impression'), st: n('started'), valid: n('valid'), clicks: n('click'), country: by('country'), device: by('device') };
  };
  if (!supabase) return <p className="note">Requiere Supabase.</p>;
  if (!adv) return (
    <>
      <h2>Publicidad</h2><p className="note">Regístrate como anunciante para crear campañas.</p>
      <form className="auth" onSubmit={async (e) => { e.preventDefault(); const { error } = await supabase!.from('advertisers').insert({ name: f.name, kind: f.kind ?? 'company' }); if (error) setMsg(error.message); else void load(); }}>
        <input required placeholder="Nombre de la empresa/artista" onChange={set('name')} />
        <select onChange={set('kind')} defaultValue="company">{Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <button className="btn">Registrarme</button>{msg && <p className="err">{msg}</p>}
      </form>
    </>
  );
  return (
    <>
      <h2>Publicidad · {adv.name}</h2>
      <p className="note">Los importes son contables: <strong>no se procesan pagos reales</strong>. Cada campaña requiere aprobación del administrador antes de emitirse. Los anuncios se identifican como «Patrocinado».</p>
      <form className="grid-form" onSubmit={async (e) => {
        e.preventDefault(); const list = (s?: string) => (s ? s.split(',').map((x) => x.trim()).filter(Boolean) : null);
        const { error } = await supabase!.from('campaigns').insert({
          advertiser_id: adv.id, title: f.title, description: f.description, format: f.format, audio_url: f.audio_url || null, image_url: f.image_url || null, link_url: f.link_url || null,
          countries: list(f.countries?.toUpperCase()), genres: list(f.genres), budget_micros: Math.round(+f.budget * 1e6), price_micros: Math.round(+f.price * 1e6),
          freq_cap_per_day: +f.freq, starts_at: f.starts, ends_at: f.ends,
        }); if (error) setMsg(error.message); else { setMsg('Campaña creada. Pendiente de aprobación.'); void load(); }
      }}>
        <input required placeholder="Título del anuncio" onChange={set('title')} />
        <input placeholder="Descripción" onChange={set('description')} />
        <select value={f.format} onChange={set('format')}>{FORMATS.map((x) => <option key={x}>{x}</option>)}</select>
        <input placeholder="URL del audio (formato audio)" onChange={set('audio_url')} />
        <input placeholder="URL de la imagen" onChange={set('image_url')} />
        <input placeholder="Enlace externo" onChange={set('link_url')} />
        <input placeholder="Países (ES,MX…) vacío = todos" onChange={set('countries')} />
        <input placeholder="Géneros (rock,pop…) vacío = todos" onChange={set('genres')} />
        <label>Presupuesto € <input type="number" step="0.01" min="0.01" value={f.budget} onChange={set('budget')} /></label>
        <label>€ por reproducción válida <input type="number" step="0.0001" min="0.0001" value={f.price} onChange={set('price')} /></label>
        <label>Máx. anuncios/día por usuario <input type="number" min="1" value={f.freq} onChange={set('freq')} /></label>
        <label>Inicio <input required type="datetime-local" onChange={set('starts')} /></label>
        <label>Fin <input required type="datetime-local" onChange={set('ends')} /></label>
        <button className="btn">Crear campaña</button>
      </form>
      {msg && <p className="note">{msg}</p>}
      {camps.map((c) => { const s = stats(c.id); return (
        <section className="card" key={c.id}>
          <strong>{c.title}</strong> <em className="badge">{c.format}</em> <em className="badge">{c.approved ? c.status : 'pendiente de aprobación'}</em>
          <p>Gastado {eur(c.spent_micros)} de {eur(c.budget_micros)} · {eur(c.price_micros)}/válida</p>
          <p className="note">Impresiones {s.imp} · Iniciadas {s.st} · <strong>Válidas {s.valid}</strong> · Clics {s.clicks}<br />Por país: {s.country}<br />Por dispositivo: {s.device}</p>
          {c.approved && ['paused', 'active'].includes(c.status) && <button className="btn ghost" onClick={async () => { await supabase!.from('campaigns').update({ status: c.status === 'active' ? 'paused' : 'active' }).eq('id', c.id); void load(); }}>{c.status === 'active' ? 'Pausar' : 'Reactivar'}</button>}
        </section>); })}
    </>
  );
}
