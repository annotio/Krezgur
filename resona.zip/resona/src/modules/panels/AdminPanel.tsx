import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

/* eslint-disable @typescript-eslint/no-explicit-any */
export default function AdminPanel() {
  const [stats, setStats] = useState<any>(null); const [users, setUsers] = useState<any[]>([]); const [camps, setCamps] = useState<any[]>([]); const [artists, setArtists] = useState<any[]>([]);
  const [q, setQ] = useState(''); const [log, setLog] = useState('');
  const load = async () => {
    setStats((await supabase!.rpc('admin_stats')).data);
    setUsers((await supabase!.from('profiles').select('id,display_name,role,plan,created_at').order('created_at', { ascending: false }).limit(200)).data ?? []);
    setCamps((await supabase!.from('campaigns').select('*').order('created_at', { ascending: false }).limit(100)).data ?? []);
    setArtists((await supabase!.from('artists').select('id,name,verified,owner_id').order('name').limit(200)).data ?? []);
  };
  useEffect(() => { void load(); }, []);
  const act = async (label: string, p: PromiseLike<{ error: any }>) => { const { error } = await p; setLog(error ? `Error: ${error.message}` : `${label} ✓`); void load(); };
  return (
    <>
      <h2>Administración</h2>
      {stats ? <div className="kpis">{Object.entries(stats).map(([k, v]) => <div key={k}><strong>{String(v)}</strong><span>{k}</span></div>)}</div> : <p className="err">Sin permisos de administrador.</p>}
      {log && <p className="note">{log}</p>}
      <h3>Campañas</h3>
      {camps.map((c) => <section className="card" key={c.id}><strong>{c.title}</strong> <em className="badge">{c.format}</em> <em className="badge">{c.approved ? c.status : 'pendiente'}</em>
        <p className="note">{(c.spent_micros / 1e6).toFixed(2)} € / {(c.budget_micros / 1e6).toFixed(2)} €</p>
        {!c.approved && <><button className="btn" onClick={() => act('Aprobada', supabase!.from('campaigns').update({ approved: true, status: 'active' }).eq('id', c.id))}>Aprobar</button>{' '}
          <button className="btn danger" onClick={() => act('Rechazada', supabase!.from('campaigns').update({ status: 'rejected' }).eq('id', c.id))}>Rechazar</button></>}
        {c.approved && <button className="btn ghost" onClick={() => act('Pausada', supabase!.from('campaigns').update({ status: 'paused' }).eq('id', c.id))}>Pausar</button>}</section>)}
      <h3>Artistas</h3>
      <input className="search" placeholder="Filtrar" value={q} onChange={(e) => setQ(e.target.value)} />
      {artists.filter((a) => a.name.toLowerCase().includes(q.toLowerCase())).slice(0, 30).map((a) => (
        <div className="row" key={a.id} style={{ gridTemplateColumns: '1fr auto auto' }}>
          <div className="meta"><strong>{a.name}</strong><span>{a.owner_id ? 'Vinculado' : 'Sin cuenta'}</span></div>
          <button className="mini" onClick={() => act('Verificación', supabase!.from('artists').update({ verified: !a.verified }).eq('id', a.id))}>{a.verified ? '✔ Verificado' : 'Verificar'}</button>
          <select defaultValue={a.owner_id ?? ''} onChange={(e) => act('Vinculado', supabase!.from('artists').update({ owner_id: e.target.value || null }).eq('id', a.id))}>
            <option value="">— sin dueño —</option>{users.map((u) => <option key={u.id} value={u.id}>{u.display_name ?? u.id.slice(0, 6)}</option>)}</select>
        </div>))}
      <h3>Usuarios y permisos</h3>
      {users.map((u) => <div className="row" key={u.id} style={{ gridTemplateColumns: '1fr auto' }}><div className="meta"><strong>{u.display_name}</strong><span>{u.plan} · {new Date(u.created_at).toLocaleDateString('es-ES')}</span></div>
        <select value={u.role} onChange={(e) => act('Rol', supabase!.from('profiles').update({ role: e.target.value }).eq('id', u.id))}>{['listener', 'artist', 'advertiser', 'admin'].map((r) => <option key={r}>{r}</option>)}</select></div>)}
    </>
  );
}
