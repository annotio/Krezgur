import { useEffect, useState } from 'react';
import type { Track } from '../../core/types';
import { fromRow } from '../catalog/catalogService';
import { player } from '../player/playerStore';
import { myPlaylists, createPlaylist, deletePlaylist, togglePublic, playlistTracks, removeFromPlaylist, reorder, type Playlist } from './libraryService';

export default function Playlists() {
  const [lists, setLists] = useState<Playlist[]>([]); const [open, setOpen] = useState<Playlist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]); const [name, setName] = useState(''); const [err, setErr] = useState('');
  const refresh = () => myPlaylists().then(setLists);
  useEffect(() => { void refresh(); }, []);
  useEffect(() => { if (open) playlistTracks(open.id, fromRow).then((r) => setTracks(r.tracks)); }, [open]);
  const move = async (i: number, d: number) => {
    const j = i + d; if (!open || j < 0 || j >= tracks.length) return;
    const next = tracks.slice(); [next[i], next[j]] = [next[j], next[i]];
    setTracks(next); await reorder(open.id, next.map((t) => t.id));
  };
  if (open) return (
    <>
      <button className="btn ghost" onClick={() => { setOpen(null); void refresh(); }}>← Playlists</button>
      <h2>{open.name}</h2>
      <p>
        <button className="btn" onClick={() => tracks.length && player.playQueue(tracks, 0)}>▶ Reproducir</button>{' '}
        <label className="note"><input type="checkbox" checked={open.is_public} onChange={async (e) => { await togglePublic(open.id, e.target.checked); setOpen({ ...open, is_public: e.target.checked }); }} /> Pública</label>{' '}
        {open.is_public && <span className="note">Compartir: {location.origin}/#pl={open.id}</span>}
      </p>
      <ul className="list">{tracks.map((t, i) => (
        <li key={t.id} className="row" style={{ gridTemplateColumns: '1fr auto auto auto auto' }}>
          <div className="meta"><strong onClick={() => player.playQueue(tracks, i)} style={{ cursor: 'pointer' }}>{t.title}</strong><span>{t.artistName}</span></div>
          <button className="mini" onClick={() => move(i, -1)} aria-label="Subir">↑</button>
          <button className="mini" onClick={() => move(i, 1)} aria-label="Bajar">↓</button>
          <button className="mini" onClick={async () => { await removeFromPlaylist(open.id, t.id); setTracks(tracks.filter((x) => x.id !== t.id)); }} aria-label="Quitar">✕</button>
        </li>))}</ul>
      {!tracks.length && <p className="note">Vacía. Añade canciones con el botón ＋ → «Añadir a playlist» desde el reproductor ampliado o la lista.</p>}
    </>
  );
  return (
    <>
      <h2>Tus playlists</h2>
      <form className="inline" onSubmit={async (e) => { e.preventDefault(); if (!name.trim()) return; try { await createPlaylist(name.trim(), false); setName(''); void refresh(); } catch (x) { setErr(String((x as Error).message)); } }}>
        <input placeholder="Nueva playlist" value={name} onChange={(e) => setName(e.target.value)} /> <button className="btn">Crear</button>
      </form>
      {err && <p className="err">{err}</p>}
      <ul className="list">{lists.map((p) => (
        <li key={p.id} className="row" style={{ gridTemplateColumns: '1fr auto auto' }}>
          <div className="meta"><strong style={{ cursor: 'pointer' }} onClick={() => setOpen(p)}>{p.name}</strong><span>{p.is_public ? 'Pública' : 'Privada'}</span></div>
          <button className="mini" onClick={() => setOpen(p)}>Abrir</button>
          <button className="mini" onClick={async () => { if (confirm('¿Eliminar playlist?')) { await deletePlaylist(p.id); void refresh(); } }}>🗑</button>
        </li>))}</ul>
      {!lists.length && <p className="note">Aún no tienes playlists.</p>}
    </>
  );
}
