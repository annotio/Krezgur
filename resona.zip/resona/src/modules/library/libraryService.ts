import type { Track } from '../../core/types';
import { supabase } from '../../lib/supabase';

/* eslint-disable @typescript-eslint/no-explicit-any */
export interface Playlist { id: string; name: string; is_public: boolean }

export async function myPlaylists(): Promise<Playlist[]> {
  if (!supabase) return [];
  const { data: u } = await supabase.auth.getUser();
  const { data } = await supabase.from('playlists').select('id,name,is_public').eq('owner_id', u.user?.id ?? '').order('created_at', { ascending: false });
  return data ?? [];
}
export async function createPlaylist(name: string, isPublic: boolean) {
  const { data, error } = await supabase!.from('playlists').insert({ name, is_public: isPublic }).select().single();
  if (error) throw error; return data as Playlist;
}
export const deletePlaylist = (id: string) => supabase!.from('playlists').delete().eq('id', id);
export const togglePublic = (id: string, v: boolean) => supabase!.from('playlists').update({ is_public: v }).eq('id', id);

export async function playlistTracks(id: string, map: (r: any) => Track): Promise<{ tracks: Track[] }> {
  const { data } = await supabase!.from('playlist_tracks').select('position, tracks(*, artists(name), albums(title))')
    .eq('playlist_id', id).order('position');
  return { tracks: (data ?? []).map((r: any) => map(r.tracks)) };
}
export async function addToPlaylist(playlistId: string, trackId: string) {
  const { count } = await supabase!.from('playlist_tracks').select('*', { count: 'exact', head: true }).eq('playlist_id', playlistId);
  return supabase!.from('playlist_tracks').upsert({ playlist_id: playlistId, track_id: trackId, position: count ?? 0 });
}
export const removeFromPlaylist = (playlistId: string, trackId: string) =>
  supabase!.from('playlist_tracks').delete().eq('playlist_id', playlistId).eq('track_id', trackId);

/** Reordenar: reescribe posiciones según el nuevo orden de ids. */
export async function reorder(playlistId: string, orderedTrackIds: string[]) {
  await Promise.all(orderedTrackIds.map((track_id, position) =>
    supabase!.from('playlist_tracks').update({ position }).eq('playlist_id', playlistId).eq('track_id', track_id)));
}
