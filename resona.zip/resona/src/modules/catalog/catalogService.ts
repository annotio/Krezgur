import type { Track } from '../../core/types';
import { providers } from '../../providers/registry';
import { supabase, isUuid } from '../../lib/supabase';
import { parseIntent, isSmart } from './intent';

/* eslint-disable @typescript-eslint/no-explicit-any */
export const fromRow = (r: any): Track => ({
  id: r.id, providerId: r.provider_id, title: r.title, artistName: r.artists?.name ?? 'Artista desconocido',
  albumTitle: r.albums?.title, coverUrl: r.cover_url, audioUrl: r.audio_url, durationSec: r.duration_sec ?? 0,
  genres: r.genres ?? [], license: r.license, commercialUse: r.commercial_use, rights: r.rights_status,
});
const SELECT = '*, artists(name), albums(title)';

async function dbTracks(order: string, limit: number): Promise<Track[]> {
  if (!supabase) return [];
  const { data } = await supabase.from('tracks').select(SELECT).order(order, { ascending: false }).limit(limit);
  return (data ?? []).map(fromRow);
}

export interface Home { latest: Track[]; popular: Track[]; source: 'database' | 'provider' | 'none' }

/** Prioridad: catálogo ingestado en la BD; si está vacío, consulta directa a los proveedores. */
export async function loadHome(): Promise<Home> {
  const latest = await dbTracks('created_at', 20);
  if (latest.length) return { latest, popular: latest.slice().reverse(), source: 'database' };
  if (providers.length) {
    const [popular, fresh] = await Promise.all([providers[0].popular(20), providers[0].latest(20)]);
    return { latest: fresh, popular, source: 'provider' };
  }
  return { latest: [], popular: [], source: 'none' };
}

export async function search(q: string): Promise<Track[]> {
  const term = q.trim();
  if (!term) return [];
  if (isSmart(term)) {                       // «música tranquila para estudiar» → géneros
    const { genres } = parseIntent(term);
    if (supabase) {
      const { data } = await supabase.from('tracks').select(SELECT).overlaps('genres', genres).limit(40);
      if (data?.length) return data.map(fromRow);
    }
    const viaTags = await Promise.all(providers.filter((p) => p.byTags).map((p) => p.byTags!(genres, 40)));
    if (viaTags.flat().length) return viaTags.flat();
  }
  if (supabase) {
    const { data } = await supabase.from('tracks').select(SELECT).ilike('title', `%${term}%`).limit(30);
    if (data?.length) return data.map(fromRow);
  }
  const results = await Promise.all(providers.map((p) => p.search(term, 30)));
  return results.flat();
}

/** Solo se registran escuchas de pistas que existen en la BD (id uuid) y con sesión iniciada. */
export async function logPlay(track: Track, listenedSec: number, completed: boolean) {
  if (!supabase || !isUuid(track.id) || listenedSec < 1) return;
  const { data } = await supabase.auth.getSession();
  if (!data.session) return;
  await supabase.from('play_events').insert({ track_id: track.id, listened_sec: Math.round(listenedSec), completed });
}

export async function listFavorites(): Promise<Track[]> {
  if (!supabase) return [];
  const { data } = await supabase.from('favorites').select(`tracks(${SELECT})`);
  return (data ?? []).map((r: any) => fromRow(r.tracks));
}
export async function setFavorite(trackId: string, on: boolean) {
  if (!supabase || !isUuid(trackId)) return;
  if (on) await supabase.from('favorites').upsert({ track_id: trackId });
  else await supabase.from('favorites').delete().eq('track_id', trackId);
}

/** Recomendaciones con reglas propias: géneros más escuchados (válidas suman, saltos restan) → pistas no escuchadas. */
export async function recommend(limit = 20): Promise<Track[]> {
  if (!supabase) return [];
  const { data: ev } = await supabase.from('play_events').select('track_id, valid, listened_sec, tracks(genres)')
    .order('created_at', { ascending: false }).limit(300);
  if (!ev?.length) return [];
  const w = new Map<string, number>(); const heard = new Set<string>();
  for (const e of ev as any[]) {
    heard.add(e.track_id);
    const delta = e.valid ? 1 : e.listened_sec < 10 ? -1 : 0;   // saltada rápido = señal negativa
    for (const g of e.tracks?.genres ?? []) w.set(g, (w.get(g) ?? 0) + delta);
  }
  const top = [...w.entries()].filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([g]) => g);
  if (!top.length) return [];
  const { data } = await supabase.from('tracks').select(SELECT).overlaps('genres', top).limit(limit * 3);
  // Mezcla para evitar recomendaciones repetitivas: descarta lo ya escuchado y baraja
  return (data ?? []).filter((r: any) => !heard.has(r.id)).sort(() => Math.random() - 0.5).slice(0, limit).map(fromRow);
}

export async function exportMyData() {
  if (!supabase) return null;
  const [profile, favorites, plays, playlists] = await Promise.all([
    supabase.from('profiles').select('*').single(), supabase.from('favorites').select('*'),
    supabase.from('play_events').select('*'), supabase.from('playlists').select('*, playlist_tracks(*)'),
  ]);
  return { profile: profile.data, favorites: favorites.data, play_events: plays.data, playlists: playlists.data };
}
