/** Búsqueda inteligente SIN IA de pago: reglas de intención en español/inglés → géneros. */
const MOODS: Record<string, { re: RegExp; genres: string[] }> = {
  entrenar: { re: /entren|gym|gimnasio|workout|correr|running/i, genres: ['rock', 'electronic', 'hiphop', 'metal', 'dance'] },
  estudiar: { re: /estudi|concentr|study|focus|trabajar/i, genres: ['ambient', 'classical', 'chillout', 'lounge', 'piano'] },
  relajar: { re: /relaj|tranquil|calm|relax|dormir|chill/i, genres: ['ambient', 'chillout', 'newage', 'acoustic', 'lounge'] },
  fiesta: { re: /fiest|salir|party|bailar|baile/i, genres: ['electronic', 'dance', 'pop', 'house', 'hiphop'] },
};
const GENRE_WORDS: Record<string, string> = {
  electr: 'electronic', rock: 'rock', pop: 'pop', jazz: 'jazz', clasic: 'classical', 'hip hop': 'hiphop', hiphop: 'hiphop',
  rap: 'hiphop', reggae: 'reggae', folk: 'folk', metal: 'metal', ambient: 'ambient', blues: 'blues',
};

export interface Intent { genres: string[]; mood?: string }
export function parseIntent(q: string): Intent {
  const genres = new Set<string>(); let mood: string | undefined;
  for (const [name, m] of Object.entries(MOODS)) if (m.re.test(q)) { mood = name; m.genres.forEach((g) => genres.add(g)); }
  const low = q.toLowerCase();
  for (const [w, g] of Object.entries(GENRE_WORDS)) if (low.includes(w)) genres.add(g);
  return { genres: [...genres], mood };
}
/** Una consulta es "inteligente" solo si es una frase con intención reconocida. */
export const isSmart = (q: string) => q.trim().split(/\s+/).length >= 2 && parseIntent(q).genres.length > 0;
