import assert from 'node:assert/strict';
import { parseIntent, isSmart } from './intent.ts';
assert.equal(parseIntent('Ponme música para entrenar').mood, 'entrenar');
assert.ok(parseIntent('música tranquila para estudiar').genres.includes('ambient'));
assert.ok(parseIntent('playlist de música electrónica para salir').genres.includes('electronic'));
assert.equal(isSmart('Daft Punk'), false);
assert.equal(isSmart('música para estudiar'), true);
console.log('intent: OK');
