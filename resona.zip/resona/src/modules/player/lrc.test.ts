import assert from 'node:assert/strict';
import { parseLrc } from './lrc.ts';
const r = parseLrc('[01:02.00]Segunda\n[00:12.50] Primera\nruido');
assert.equal(r.length, 2); assert.equal(r[0].t, 12.5); assert.equal(r[0].text, 'Primera'); assert.equal(r[1].t, 62);
console.log('lrc: OK');
