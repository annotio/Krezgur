import { usePlayer, currentTrack, player } from './playerStore';

const fmt = (s: number) => (isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '0:00');

export default function PlayerBar({ onExpand }: { onExpand: () => void }) {
  const s = usePlayer();
  const t = currentTrack(s);
  if (!t) return <footer className="player idle">Elige una canción para empezar</footer>;
  return (
    <footer className="player">
      <div className="now">
        {t.coverUrl ? <img src={t.coverUrl} alt="" onClick={onExpand} style={{ cursor: 'pointer' }} /> : <div className="ph" />}
        <div><strong>{s.ad ? 'Anuncio' : t.title}</strong><span>{s.ad ? <em className="badge warn">Patrocinado · {s.ad}</em> : t.artistName}</span></div>
      </div>
      <div className="center">
        <div className="btns">
          <button className={s.shuffle ? 'on' : ''} onClick={player.toggleShuffle} aria-label="Aleatorio">⤮</button>
          <button onClick={player.prev} aria-label="Anterior">⏮</button>
          <button className="play" onClick={player.toggle} aria-label="Reproducir/Pausar">{s.playing ? '⏸' : '▶'}</button>
          <button onClick={player.next} aria-label="Siguiente">⏭</button>
          <button className={s.repeat !== 'off' ? 'on' : ''} onClick={player.cycleRepeat} aria-label="Repetir">{s.repeat === 'one' ? '🔂' : '🔁'}</button>
        </div>
        {s.error ? <p className="err">{s.error}</p> : (
          <div className="bar">
            <span>{fmt(s.position)}</span>
            <input type="range" min={0} max={s.duration || 1} step={1} value={s.position} onChange={(e) => player.seek(+e.target.value)} />
            <span>{fmt(s.duration)}</span>
          </div>
        )}
      </div>
      <div className="side">
        <button onClick={onExpand} aria-label="Pantalla ampliada">⤢</button>
        <select value={s.sleepAt ? 'on' : ''} onChange={(e) => player.sleepIn(e.target.value ? +e.target.value : null)} aria-label="Temporizador">
          <option value="">💤 Off</option><option value="15">15 min</option><option value="30">30 min</option><option value="60">60 min</option>
        </select>
        <input type="range" min={0} max={1} step={0.01} value={s.volume} onChange={(e) => player.setVolume(+e.target.value)} aria-label="Volumen" />
      </div>
    </footer>
  );
}
