import { useEffect, useState } from 'react';
import { usePlayer, currentTrack, player } from './playerStore';
import { supabase, isUuid } from '../../lib/supabase';
import { parseLrc, type Line } from './lrc';

export default function NowPlaying({ onClose }: { onClose: () => void }) {
  const s = usePlayer(); const t = currentTrack(s);
  const [lines, setLines] = useState<Line[] | null>(null); const [plain, setPlain] = useState<string | null>(null);
  useEffect(() => {
    setLines(null); setPlain(null);
    if (!t || !supabase || !isUuid(t.id)) return;
    supabase.from('lyrics').select('synced_lrc, plain').eq('track_id', t.id).maybeSingle().then(({ data }) => {
      if (data?.synced_lrc) setLines(parseLrc(data.synced_lrc)); else if (data?.plain) setPlain(data.plain);
    });
  }, [t?.id]);
  useEffect(() => { document.querySelector('.lyric.cur')?.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, [s.position]);
  if (!t) return null;
  const cur = lines ? lines.reduce((acc, l, i) => (l.t <= s.position ? i : acc), -1) : -1;
  return (
    <div className="np" role="dialog" aria-label="Reproduciendo">
      <button className="close" onClick={onClose} aria-label="Cerrar">⌄</button>
      <div className="np-body">
        <div className="np-cover">{t.coverUrl ? <img src={t.coverUrl} alt="" /> : <div className="ph" />}
          <h2>{t.title}</h2><p>{t.artistName}</p>
          <div className="btns"><button onClick={player.prev}>⏮</button><button className="play" onClick={player.toggle}>{s.playing ? '⏸' : '▶'}</button><button onClick={player.next}>⏭</button></div>
        </div>
        <div className="lyrics">
          {lines ? lines.map((l, i) => <p key={i} className={'lyric' + (i === cur ? ' cur' : '')}>{l.text || '♪'}</p>)
            : plain ? <pre>{plain}</pre>
            : <p className="note">Letras no disponibles: no hay una fuente autorizada para esta canción.</p>}
        </div>
      </div>
    </div>
  );
}
