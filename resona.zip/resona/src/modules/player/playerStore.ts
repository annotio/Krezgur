import { useSyncExternalStore } from 'react';
import type { Track } from '../../core/types';
import { logPlay } from '../catalog/catalogService';
import { ADS_ENABLED, pickAd, recordAdEvent } from '../ads/adService';
import { classifyAd } from '../ads/adRules';

export interface PlayerState {
  queue: Track[]; index: number; playing: boolean; position: number; duration: number;
  volume: number; shuffle: boolean; repeat: 'off' | 'all' | 'one'; error: string | null; sleepAt: number | null; ad: string | null;
}
let state: PlayerState = {
  queue: [], index: -1, playing: false, position: 0, duration: 0,
  volume: Number(localStorage.getItem('rs.volume') ?? 0.8), shuffle: false, repeat: 'off', error: null, sleepAt: null, ad: null,
};
const listeners = new Set<() => void>();
const set = (p: Partial<PlayerState>) => { state = { ...state, ...p }; listeners.forEach((l) => l()); };

const audio = new Audio();
audio.preload = 'metadata';
audio.volume = state.volume;
let listened = 0, lastT = 0;

// --- Pausas publicitarias (solo si VITE_ADS_ENABLED=true, hay sesión y consentimiento) ---
let songsSinceAd = 0;
const adAudio = new Audio();
async function adBreak(): Promise<void> {
  if (!ADS_ENABLED || songsSinceAd < 3) return;
  const ad = await pickAd('audio');
  if (!ad?.audio_url) return;
  songsSinceAd = 0; audio.pause(); set({ ad: ad.title });
  await new Promise<void>((resolve) => {
    let heard = 0, last = 0, started = false;
    adAudio.src = ad.audio_url!; adAudio.volume = state.volume;
    const onTime = () => {
      const d = adAudio.currentTime - last; last = adAudio.currentTime;
      if (d > 0 && d < 2) heard += d;
      if (!started && heard > 0) { started = true; void recordAdEvent(ad.id, 'started'); }
    };
    const done = () => {
      adAudio.removeEventListener('timeupdate', onTime); adAudio.removeEventListener('ended', done); adAudio.removeEventListener('error', done);
      const stage = classifyAd({ format: 'audio', adDurationSec: adAudio.duration || 0, listenedSec: heard, skipped: false, visibleMs: 0, clicked: false });
      if (stage === 'valid') void recordAdEvent(ad.id, 'valid');
      set({ ad: null }); resolve();
    };
    adAudio.addEventListener('timeupdate', onTime); adAudio.addEventListener('ended', done); adAudio.addEventListener('error', done);
    adAudio.play().catch(done);
  });
}
async function advance(i: number) { songsSinceAd++; await adBreak(); await load(i); }

const current = () => state.queue[state.index];

function flushLog(completed: boolean) {
  const t = current();
  if (t) void logPlay(t, listened, completed);
  listened = 0;
}

async function load(i: number, startAt = 0) {
  flushLog(false);
  const t = state.queue[i];
  set({ index: i, position: startAt, duration: t?.durationSec ?? 0, error: null });
  if (!t) return;
  // Regla central: solo se reproduce lo que tiene fuente de audio autorizada. Nada simulado.
  if (t.rights !== 'playable_licensed' || !t.audioUrl) {
    audio.pause(); set({ playing: false, error: 'Esta canción no tiene una fuente de audio autorizada.' }); return;
  }
  audio.src = t.audioUrl; lastT = startAt;
  if (startAt) audio.currentTime = startAt;
  try { await audio.play(); set({ playing: true }); } catch { set({ playing: false }); }
  if ('mediaSession' in navigator) {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: t.title, artist: t.artistName, album: t.albumTitle ?? '',
      artwork: t.coverUrl ? [{ src: t.coverUrl, sizes: '300x300' }] : [],
    });
  }
}

function pickNext(dir: 1 | -1): number {
  const n = state.queue.length;
  if (!n) return -1;
  if (state.shuffle && n > 1) { let r = state.index; while (r === state.index) r = Math.floor(Math.random() * n); return r; }
  const next = state.index + dir;
  if (next >= 0 && next < n) return next;
  return state.repeat === 'all' ? (next + n) % n : -1;
}

audio.addEventListener('timeupdate', () => {
  const d = audio.currentTime - lastT; lastT = audio.currentTime;
  if (d > 0 && d < 2) listened += d;               // suma solo tiempo realmente escuchado
  set({ position: audio.currentTime, duration: audio.duration || state.duration });
  const t = current(); if (t) localStorage.setItem('rs.last', JSON.stringify({ id: t.id, pos: audio.currentTime }));
  if (state.sleepAt && Date.now() >= state.sleepAt) { audio.pause(); set({ playing: false, sleepAt: null }); }
});
audio.addEventListener('ended', () => {
  flushLog(true);
  if (state.repeat === 'one') { audio.currentTime = 0; void audio.play(); return; }
  const n = pickNext(1); if (n >= 0) void advance(n); else set({ playing: false });
});
audio.addEventListener('error', () => set({ playing: false, error: 'No se pudo cargar el audio.' }));

export const player = {
  playQueue(queue: Track[], index: number) { set({ queue }); void load(index); },
  toggle() {
    if (!current() || state.error || state.ad) return;
    if (audio.paused) { void audio.play(); set({ playing: true }); } else { audio.pause(); set({ playing: false }); }
  },
  next() { if (state.ad) return; const n = pickNext(1); if (n >= 0) void advance(n); },
  prev() { if (audio.currentTime > 3) { audio.currentTime = 0; return; } const n = pickNext(-1); if (n >= 0) void load(n); },
  seek(s: number) { audio.currentTime = s; set({ position: s }); },
  setVolume(v: number) { audio.volume = v; localStorage.setItem('rs.volume', String(v)); set({ volume: v }); },
  toggleShuffle() { set({ shuffle: !state.shuffle }); },
  cycleRepeat() { set({ repeat: state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off' }); },
  enqueue(t: Track) { set({ queue: [...state.queue, t] }); },
  sleepIn(min: number | null) { set({ sleepAt: min ? Date.now() + min * 60_000 : null }); },
};

if ('mediaSession' in navigator) {
  navigator.mediaSession.setActionHandler('play', () => player.toggle());
  navigator.mediaSession.setActionHandler('pause', () => player.toggle());
  navigator.mediaSession.setActionHandler('nexttrack', () => player.next());
  navigator.mediaSession.setActionHandler('previoustrack', () => player.prev());
}

export const usePlayer = () =>
  useSyncExternalStore((cb) => { listeners.add(cb); return () => { listeners.delete(cb); }; }, () => state);
export const currentTrack = (s: PlayerState) => s.queue[s.index];
