export interface Line { t: number; text: string }
/** Parsea letras sincronizadas en formato LRC: «[mm:ss.xx] texto». */
export function parseLrc(lrc: string): Line[] {
  const out: Line[] = [];
  for (const row of lrc.split('\n')) {
    const m = row.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/);
    if (m) out.push({ t: +m[1] * 60 + +m[2], text: m[3].trim() });
  }
  return out.sort((a, b) => a.t - b.t);
}
